import { tokens } from '../tokens';

export const es = {
  [tokens.common.languageChanged]: 'Se ha cambiado el idioma',
  [tokens.nav.overview]: 'Visión general'
};
