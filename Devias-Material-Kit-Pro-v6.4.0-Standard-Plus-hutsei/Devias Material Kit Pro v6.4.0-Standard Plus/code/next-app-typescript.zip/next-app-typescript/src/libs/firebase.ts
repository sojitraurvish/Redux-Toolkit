import { initializeApp } from 'firebase/app';

import { firebaseConfig } from 'src/config';

export const firebaseApp = initializeApp(firebaseConfig);
