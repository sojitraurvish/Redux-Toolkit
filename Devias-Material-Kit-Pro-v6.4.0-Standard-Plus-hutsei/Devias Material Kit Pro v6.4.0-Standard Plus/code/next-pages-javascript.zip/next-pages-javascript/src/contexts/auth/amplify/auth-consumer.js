import { AuthContext } from './auth-context';

export const AuthConsumer = AuthContext.Consumer;
