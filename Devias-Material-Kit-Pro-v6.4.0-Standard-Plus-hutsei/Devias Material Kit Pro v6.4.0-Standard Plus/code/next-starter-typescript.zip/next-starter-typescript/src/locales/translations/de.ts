import { tokens } from '../tokens';

export const de = {
  [tokens.common.languageChanged]: 'Sprache geändert',
  [tokens.nav.overview]: 'Überblick'
};
