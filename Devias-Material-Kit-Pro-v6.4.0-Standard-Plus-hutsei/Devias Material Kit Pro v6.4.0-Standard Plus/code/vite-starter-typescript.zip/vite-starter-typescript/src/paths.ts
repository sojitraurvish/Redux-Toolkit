export const paths = {
  index: '/',
  blank: '/blank',
  docs: 'https://material-kit-pro-react-docs.devias.io'
};
